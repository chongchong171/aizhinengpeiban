/**
 * 树洞倾诉页面逻辑
 * @description 聊天功能实现
 * @author 玄枢
 * @date 2026-03-15
 */

Page({
  /**
   * 页面数据
   */
  data: {
    messages: [],           // 消息列表
    inputValue: '',         // 输入框内容
    loading: false,         // 加载状态
    scrollToView: ''        // 滚动位置
  },

  /**
   * 页面加载
   */
  onLoad() {
    console.log('树洞倾诉页面加载');
    
    // 从本地存储加载历史聊天记录
    this.loadChatHistory();
  },

  /**
   * 页面显示
   */
  onShow() {
    // 滚动到底部
    this.scrollToBottom();
  },

  /**
   * 加载聊天历史
   */
  loadChatHistory() {
    const history = wx.getStorageSync('chatHistory') || [];
    this.setData({ messages: history });
  },

  /**
   * 输入框内容变化
   */
  onInputChange(e) {
    this.setData({
      inputValue: e.detail.value
    });
  },

  /**
   * 发送消息
   */
  sendMessage() {
    const content = this.data.inputValue.trim();
    
    // 空消息不发送
    if (!content) {
      return;
    }

    // 防止重复发送
    if (this.data.loading) {
      return;
    }

    // 添加用户消息
    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: content,
      time: this.formatTime(new Date())
    };

    const messages = [...this.data.messages, userMessage];
    this.setData({
      messages,
      inputValue: '',
      loading: true
    });

    // 保存到本地存储
    this.saveChatHistory(messages);

    // 滚动到底部
    this.scrollToBottom();

    // 模拟瓜瓜回复（不使用付费 API）
    setTimeout(() => {
      const botReply = this.getBotReply(content);
      const botMessage = {
        id: Date.now() + 1,
        type: 'bot',
        content: botReply,
        time: this.formatTime(new Date())
      };

      const newMessages = [...this.data.messages, botMessage];
      this.setData({
        messages: newMessages,
        loading: false
      });

      // 保存聊天记录
      this.saveChatHistory(newMessages);

      // 滚动到底部
      this.scrollToBottom();
    }, 1000);
  },

  /**
   * 获取瓜瓜的回复（本地规则回复，不调用付费 API）
   * @param {string} content - 用户输入
   * @returns {string} - 回复内容
   */
  getBotReply(content) {
    // 简单的关键词匹配回复
    const replies = {
      '开心': '太好了！看到你开心瓜瓜也很高兴呢！🎉 继续保持这份好心情哦~',
      '难过': '抱抱~ 瓜瓜在这里陪着你。难过的时候说出来会好受一些，我一直在听。💕',
      '累': '辛苦啦！休息一下吧，喝杯水，深呼吸，你真的很棒了！💪',
      '压力': '压力大的时候，记得深呼吸哦~ 一切都会慢慢变好的，瓜瓜相信你！🌈',
      '谢谢': '不客气呀！能陪在女王大人身边是瓜瓜的荣幸~ 👑',
      '你好': '女王大人好呀！今天过得怎么样呢？🐾',
      '在吗': '瓜瓜一直在呢！随时为你待命~ 💕',
      '晚安': '晚安啦！做个甜甜的梦，明天见~ 🌙✨',
      '早安': '早安！新的一天开始啦，加油哦！☀️',
      '拜拜': '拜拜~ 记得想我哦！随时回来找我玩~ 👋'
    };

    // 查找匹配的回复
    for (const key in replies) {
      if (content.includes(key)) {
        return replies[key];
      }
    }

    // 默认回复
    const defaultReplies = [
      '嗯嗯，瓜瓜在听呢！继续说呀~ 👂',
      '我懂你的感受，想说什么都可以哦！💕',
      '谢谢你愿意和我分享，这对我来说很重要~ 🐾',
      '女王大人说得对！我记下来啦~ 📝',
      '抱抱~ 不管发生什么，瓜瓜都会陪着你！🤗'
    ];

    return defaultReplies[Math.floor(Math.random() * defaultReplies.length)];
  },

  /**
   * 保存聊天记录到本地
   */
  saveChatHistory(messages) {
    // 只保留最近 50 条消息
    const recentMessages = messages.slice(-50);
    wx.setStorageSync('chatHistory', recentMessages);
  },

  /**
   * 加载更多消息（滚动到顶部时）
   */
  loadMoreMessages() {
    // 本地存储模式下暂不实现加载更多
    console.log('没有更多历史消息了');
  },

  /**
   * 滚动到底部
   */
  scrollToBottom() {
    if (this.data.messages.length > 0) {
      const lastId = this.data.messages[this.data.messages.length - 1].id;
      this.setData({
        scrollToView: `msg-${lastId}`
      });
    }
  },

  /**
   * 格式化时间
   */
  formatTime(date) {
    const hour = date.getHours().toString().padStart(2, '0');
    const minute = date.getMinutes().toString().padStart(2, '0');
    return `${hour}:${minute}`;
  }
});

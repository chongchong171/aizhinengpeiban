/**
 * 首页逻辑
 * @description 主菜单页面功能实现
 * @author 玄枢
 * @date 2026-03-15
 */

Page({
  /**
   * 页面数据
   */
  data: {
    // 每日鼓励语（可后续改为从后端获取）
    dailyQuote: '今天也是闪闪发光的一天呢！瓜瓜会一直陪着你~ ✨'
  },

  /**
   * 页面加载
   */
  onLoad() {
    console.log('首页加载完成');
    
    // 设置每日鼓励语
    this.setDailyQuote();
  },

  /**
   * 页面显示
   */
  onShow() {
    // 每次显示时更新鼓励语
    this.setDailyQuote();
  },

  /**
   * 设置每日鼓励语
   * 根据时间段显示不同的问候语
   */
  setDailyQuote() {
    const hour = new Date().getHours();
    let quote = '';
    
    if (hour >= 5 && hour < 9) {
      quote = '早安呀！新的一天，新的开始，瓜瓜为你加油！☀️';
    } else if (hour >= 9 && hour < 12) {
      quote = '上午好！工作再忙也要记得休息哦~ 💪';
    } else if (hour >= 12 && hour < 14) {
      quote = '午安！吃饱了才有力气继续战斗呢！🍱';
    } else if (hour >= 14 && hour < 18) {
      quote = '下午好！坚持一下，离下班又近了一步！🌈';
    } else if (hour >= 18 && hour < 22) {
      quote = '晚上好！辛苦了一天，好好放松一下吧~ 🌙';
    } else {
      quote = '夜深啦，早点休息，明天见！好梦~ 💤';
    }
    
    this.setData({ dailyQuote: quote });
  },

  /**
   * 导航到指定页面
   * @param {Object} e - 点击事件对象
   */
  navigateTo(e) {
    const page = e.currentTarget.dataset.page;
    
    // 检查页面是否存在
    if (!page) {
      wx.showToast({
        title: '页面开发中...',
        icon: 'none'
      });
      return;
    }
    
    // 执行页面跳转
    wx.navigateTo({
      url: page,
      fail: () => {
        wx.showToast({
          title: '页面开发中...',
          icon: 'none'
        });
      }
    });
  }
});

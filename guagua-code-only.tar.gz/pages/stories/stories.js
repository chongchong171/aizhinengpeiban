/**
 * 睡前故事页面逻辑
 * @description 故事列表展示和播放功能
 * @author 玄枢
 * @date 2026-03-15
 * @note 故事数据待千夜交付，目前使用 placeholder 数据
 */

Page({
  /**
   * 页面数据
   */
  data: {
    currentCategory: 'all',     // 当前分类
    stories: [],                // 故事列表
    isPlaying: false,           // 是否正在播放
    isPaused: false,            // 是否暂停
    currentStory: {},           // 当前播放的故事
    showDetail: false           // 是否显示详情弹窗
  },

  /**
   * 页面加载
   */
  onLoad() {
    this.loadStories();
  },

  /**
   * 加载故事列表
   * @note 目前使用 placeholder 数据，等待千夜交付真实数据
   */
  loadStories() {
    // Placeholder 故事数据（待替换为千夜交付的数据）
    const placeholderStories = [
      {
        id: 1,
        title: '小兔子的月亮',
        description: '一只小兔子想要摘下月亮送给妈妈，踏上了一场温暖的冒险...',
        duration: 15,
        views: 1234,
        category: 'warm',
        cover: '🌙'
      },
      {
        id: 2,
        title: '星星的约定',
        description: '在遥远的星空里，有一颗专门为好孩子闪烁的星星...',
        duration: 12,
        views: 987,
        category: 'warm',
        cover: '⭐'
      },
      {
        id: 3,
        title: '森林音乐会',
        description: '小动物们举办了一场盛大的音乐会，每个角色都有独特的乐器...',
        duration: 18,
        views: 756,
        category: 'adventure',
        cover: '🎵'
      },
      {
        id: 4,
        title: '云朵枕头',
        description: '睡不着的时候，就想象自己躺在柔软的云朵上...',
        duration: 10,
        views: 2341,
        category: 'bedtime',
        cover: '☁️'
      },
      {
        id: 5,
        title: '彩虹桥的故事',
        description: '雨过天晴后，彩虹桥连接了两个世界...',
        duration: 20,
        views: 1567,
        category: 'adventure',
        cover: '🌈'
      }
    ];

    this.setData({
      stories: placeholderStories
    });
  },

  /**
   * 切换分类
   */
  switchCategory(e) {
    const category = e.currentTarget.dataset.category;
    this.setData({ currentCategory: category });

    // 筛选故事
    if (category === 'all') {
      this.loadStories();
    } else {
      const filtered = this.data.stories.filter(story => story.category === category);
      this.setData({ stories: filtered });
    }
  },

  /**
   * 打开故事详情
   */
  openStory(e) {
    const id = e.currentTarget.dataset.id;
    const story = this.data.stories.find(s => s.id === id);
    
    if (story) {
      this.setData({
        currentStory: story,
        showDetail: true
      });
    }
  },

  /**
   * 关闭详情弹窗
   */
  closeDetail() {
    this.setData({
      showDetail: false
    });
  },

  /**
   * 开始播放故事
   * @note 实际播放功能待实现，需要音频播放组件
   */
  startPlay() {
    this.setData({
      showDetail: false,
      isPlaying: true,
      isPaused: false
    });

    wx.showToast({
      title: '开始播放',
      icon: 'none'
    });

    // TODO: 对接音频播放功能
    console.log('开始播放故事:', this.data.currentStory.title);
  },

  /**
   * 切换播放/暂停
   */
  togglePlay() {
    this.setData({
      isPaused: !this.data.isPaused
    });

    wx.showToast({
      title: this.data.isPaused ? '已暂停' : '继续播放',
      icon: 'none'
    });
  },

  /**
   * 停止播放
   */
  stopPlay() {
    this.setData({
      isPlaying: false,
      isPaused: false,
      currentStory: {}
    });

    wx.showToast({
      title: '已停止',
      icon: 'none'
    });
  }
});

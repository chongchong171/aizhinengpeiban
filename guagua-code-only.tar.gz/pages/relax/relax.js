/**
 * 放松引导页面逻辑
 * @description 呼吸引导和放松练习功能
 * @author 玄枢
 * @date 2026-03-15
 */

Page({
  /**
   * 页面数据
   */
  data: {
    isBreathing: false,         // 是否正在进行呼吸练习
    breathingState: '',         // 呼吸状态：inhale（吸气）/ exhale（呼气）
    breathingText: '准备开始',   // 呼吸引导文字
    selectedMode: 'breathe',    // 选择的引导模式
    showTimer: false,           // 是否显示倒计时
    timerDisplay: '05:00',      // 倒计时显示
    timerInterval: null         // 定时器 ID
  },

  /**
   * 页面卸载时清理定时器
   */
  onUnload() {
    this.clearTimer();
  },

  /**
   * 切换呼吸练习状态
   */
  toggleBreathing() {
    if (this.data.isBreathing) {
      this.pauseBreathing();
    } else {
      this.startBreathing();
    }
  },

  /**
   * 开始呼吸练习
   * 使用 4-7-8 呼吸法：吸气 4 秒，屏息 7 秒，呼气 8 秒
   */
  startBreathing() {
    this.setData({ isBreathing: true, showTimer: true });
    
    // 启动呼吸引导循环
    this.breathingCycle();
    
    // 启动倒计时（5 分钟）
    this.startTimer(300);
  },

  /**
   * 呼吸循环
   */
  breathingCycle() {
    if (!this.data.isBreathing) return;

    // 吸气阶段（4 秒）
    this.setData({
      breathingState: 'inhale',
      breathingText: '吸气...'
    });

    // 4 秒后进入呼气阶段
    setTimeout(() => {
      if (!this.data.isBreathing) return;

      this.setData({
        breathingState: 'exhale',
        breathingText: '呼气...'
      });

      // 8 秒后再次吸气
      setTimeout(() => {
        if (this.data.isBreathing) {
          this.breathingCycle();
        }
      }, 8000);
    }, 4000);
  },

  /**
   * 暂停呼吸练习
   */
  pauseBreathing() {
    this.setData({
      isBreathing: false,
      breathingState: '',
      breathingText: '已暂停'
    });
    
    this.clearTimer();
  },

  /**
   * 重置呼吸练习
   */
  resetBreathing() {
    this.pauseBreathing();
    this.setData({
      breathingText: '准备开始',
      timerDisplay: '05:00'
    });
  },

  /**
   * 选择引导模式
   */
  selectMode(e) {
    const mode = e.currentTarget.dataset.mode;
    this.setData({ selectedMode: mode });
    
    // 切换模式时重置状态
    this.resetBreathing();
    
    wx.showToast({
      title: `已切换到${this.getModeName(mode)}`,
      icon: 'none'
    });
  },

  /**
   * 获取模式名称
   */
  getModeName(mode) {
    const names = {
      breathe: '呼吸练习',
      relax: '身体放松',
      meditate: '冥想引导'
    };
    return names[mode] || '呼吸练习';
  },

  /**
   * 启动倒计时
   */
  startTimer(seconds) {
    this.clearTimer();
    
    let remaining = seconds;
    
    const updateTimer = () => {
      const minutes = Math.floor(remaining / 60);
      const secs = remaining % 60;
      const display = `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
      
      this.setData({ timerDisplay: display });
      
      if (remaining <= 0) {
        this.completeSession();
        return;
      }
      
      remaining--;
      
      const interval = setInterval(updateTimer, 1000);
      this.setData({ timerInterval: interval });
    };
    
    updateTimer();
  },

  /**
   * 完成练习 session
   */
  completeSession() {
    this.clearTimer();
    this.setData({
      isBreathing: false,
      breathingState: '',
      breathingText: '练习完成！'
    });
    
    wx.showToast({
      title: '太棒了！完成练习~',
      icon: 'success'
    });
  },

  /**
   * 清理定时器
   */
  clearTimer() {
    if (this.data.timerInterval) {
      clearInterval(this.data.timerInterval);
      this.setData({ timerInterval: null });
    }
  }
});

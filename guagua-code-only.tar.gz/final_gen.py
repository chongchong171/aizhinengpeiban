#!/usr/bin/env python3
"""最终生成脚本 - 可靠版本"""
import dashscope
from dashscope import ImageSynthesis
import requests
import time
import os

dashscope.api_key = 'sk-d43b58a6d0dd486d89b69a38f305483a'

def download(url, path):
    """下载图片"""
    try:
        data = requests.get(url, timeout=30).content
        with open(path, 'wb') as f:
            f.write(data)
        return True
    except Exception as e:
        print(f"下载失败：{e}")
        return False

def gen(prompt, path, size="1024*1024"):
    """生成单张图片"""
    print(f"🎨 {os.path.basename(path)}")
    try:
        resp = ImageSynthesis.call(
            model='wanx-v1',
            prompt=prompt,
            size=size,
            n=1  # 只生成 1 张
        )
        
        if resp.status_code == 200 and resp.output.task_status == 'SUCCEEDED':
            url = resp.output.results[0].url
            if download(url, path):
                print(f"   ✅ OK")
                return True
        print(f"   ❌ 失败")
        return False
    except Exception as e:
        print(f"   ❌ {e}")
        return False

# 确保目录存在
os.makedirs("/root/.openclaw/workspace/guagua-miniprogram/images/icons", exist_ok=True)
os.makedirs("/root/.openclaw/workspace/guagua-miniprogram/images/backgrounds", exist_ok=True)
os.makedirs("/root/.openclaw/workspace/guagua-miniprogram/images/goodnight", exist_ok=True)

print("=" * 50)
print("开始生成 UI 素材")
print("=" * 50)

# 图标（补充剩余的 2 个）
print("\n【图标】")
gen("闹钟图标，睡前提醒功能，柔和橙色，圆润可爱，简洁扁平化设计", 
    "/root/.openclaw/workspace/guagua-miniprogram/images/icons/icon-alarm.png")
time.sleep(1)

gen("用户个人中心图标，简洁人形轮廓，温暖紫色调，圆润友好，扁平化",
    "/root/.openclaw/workspace/guagua-miniprogram/images/icons/icon-user.png")
time.sleep(1)

# 背景图
print("\n【背景图】")
gen("温暖夜空背景，深蓝色渐变到紫色，散布闪闪小星星和弯弯月亮，柔和云朵，治愈系，低饱和度",
    "/root/.openclaw/workspace/guagua-miniprogram/images/backgrounds/bg-home.png", "928*1664")
time.sleep(1)

gen("聊天背景图，柔和淡紫色和淡蓝色渐变，轻盈云朵图案，温暖治愈，简洁不抢眼",
    "/root/.openclaw/workspace/guagua-miniprogram/images/backgrounds/bg-chat.png", "928*1664")
time.sleep(1)

gen("睡前故事背景，温馨暖橙色调，柔和光晕，书本和星星元素，治愈系温暖安心",
    "/root/.openclaw/workspace/guagua-miniprogram/images/backgrounds/bg-story.png", "928*1664")
time.sleep(1)

# 晚安图
print("\n【晚安图】")
gen("晚安图模板，委屈情绪主题，温暖抱抱的治愈场景，柔和紫色调，预留文字位置，温馨安慰",
    "/root/.openclaw/workspace/guagua-miniprogram/images/goodnight/goodnight-sad.png", "928*1664")
time.sleep(1)

gen("晚安图模板，开心情绪主题，欢快温暖场景，明亮橙黄色调，星星和彩带，预留文字位置",
    "/root/.openclaw/workspace/guagua-miniprogram/images/goodnight/goodnight-happy.png", "928*1664")
time.sleep(1)

gen("晚安图模板，疲惫情绪主题，宁静放松场景，淡蓝色调，月亮和云朵，预留文字位置",
    "/root/.openclaw/workspace/guagua-miniprogram/images/goodnight/goodnight-tired.png", "928*1664")
time.sleep(1)

gen("晚安图模板，焦虑情绪主题，平静安心场景，柔和绿色和蓝色，预留文字位置，温暖希望",
    "/root/.openclaw/workspace/guagua-miniprogram/images/goodnight/goodnight-anxious.png", "928*1664")
time.sleep(1)

gen("晚安图模板，平静情绪主题，宁静夜空，深蓝色调，星星月亮，预留文字位置，晚安好梦",
    "/root/.openclaw/workspace/guagua-miniprogram/images/goodnight/goodnight-peaceful.png", "928*1664")
time.sleep(1)

print("\n" + "=" * 50)
print("✅ 生成完成！")
print("=" * 50)

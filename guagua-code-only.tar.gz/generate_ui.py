#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
瓜瓜陪伴小程序 UI 素材生成脚本
使用阿里云 wanx-v1 模型（免费额度）
"""

import os
import dashscope
from dashscope import ImageSynthesis
import time

# API Key 配置
DASHSCOPE_API_KEY = "sk-d43b58a6d0dd486d89b69a38f305483a"
dashscope.api_key = DASHSCOPE_API_KEY

# 输出目录
OUTPUT_DIR = "/root/.openclaw/workspace/guagua-miniprogram/images"

# 通用负向提示词（避免低质量）
NEGATIVE_PROMPT = "低分辨率，低画质，模糊，文字扭曲，肢体畸形，手指畸形，画面过饱和，蜡像感，人脸无细节，过度光滑，画面具有 AI 感，构图混乱，文字模糊，扭曲，水印，边框"

def generate_image(prompt, size, output_path, negative_prompt=NEGATIVE_PROMPT):
    """生成单张图片"""
    print(f"🎨 正在生成：{output_path}")
    print(f"   提示词：{prompt[:50]}...")
    print(f"   尺寸：{size}")
    
    try:
        response = ImageSynthesis.call(
            model=ImageSynthesis.Models.wanx_v1,
            prompt=prompt,
            negative_prompt=negative_prompt,
            size=size,
            n=1
        )
        
        if response.status_code == 200:
            # 获取图片 URL
            img_url = response.output.results[0].url
            print(f"   ✅ 生成成功：{img_url}")
            
            # 下载图片
            import requests
            img_data = requests.get(img_url).content
            with open(output_path, 'wb') as f:
                f.write(img_data)
            print(f"   💾 已保存：{output_path}")
            return True
        else:
            print(f"   ❌ 生成失败：{response.message}")
            return False
            
    except Exception as e:
        print(f"   ❌ 错误：{e}")
        return False

def main():
    """主函数 - 批量生成所有 UI 素材"""
    
    # 确保输出目录存在
    os.makedirs(f"{OUTPUT_DIR}/logo", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/icons", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/backgrounds", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/goodnight", exist_ok=True)
    
    print("=" * 60)
    print("🎨 瓜瓜陪伴小程序 UI 素材生成")
    print("=" * 60)
    
    # ========== 1. Logo 设计 (512x512) ==========
    print("\n📌 第一部分：Logo 设计")
    logo_prompts = [
        ("logo.png", "可爱的 AI 小助手瓜瓜 logo，圆润温暖的卡通形象，紫色和蓝色渐变配色，治愈系风格，简洁现代，透明背景，512x512 像素，小程序图标")
    ]
    
    for filename, prompt in logo_prompts:
        generate_image(prompt, "1024*1024", f"{OUTPUT_DIR}/logo/{filename}")
        time.sleep(2)
    
    # ========== 2. 功能图标 (7 个，81x81 实际输出用 512x512 后缩放) ==========
    print("\n📌 第二部分：功能图标集（优先级最高 ⭐）")
    icon_prompts = [
        ("icon-chat.png", "对话气泡图标，树洞倾诉功能，温暖紫色调，圆润简洁线条，治愈系风格，扁平化设计，透明背景"),
        ("icon-star.png", "闪闪发光的星星图标，今日亮点功能，金黄色温暖色调，简洁可爱，治愈系风格，扁平化设计，透明背景"),
        ("icon-book.png", "打开的书本图标，睡前故事功能，柔和橙色色调，圆润简洁，治愈系风格，扁平化设计，透明背景"),
        ("icon-meditate.png", "冥想放松图标，莲花或禅意符号，淡蓝色调，宁静治愈，简洁线条，扁平化设计，透明背景"),
        ("icon-moon.png", "弯弯的月亮图标，晚安图片功能，淡紫色夜空色调，星星点缀，治愈系风格，扁平化设计，透明背景"),
        ("icon-alarm.png", "闹钟图标，睡前提醒功能，柔和橙色调，圆润可爱，简洁现代，治愈系风格，扁平化设计，透明背景"),
        ("icon-user.png", "用户个人中心图标，简洁人形轮廓，温暖紫色调，圆润友好，扁平化设计，透明背景")
    ]
    
    for filename, prompt in icon_prompts:
        generate_image(prompt, "1024*1024", f"{OUTPUT_DIR}/icons/{filename}")
        time.sleep(2)
    
    # ========== 3. 背景图 (3 个，750x1334 用 928*1664 近似) ==========
    print("\n📌 第三部分：背景图")
    bg_prompts = [
        ("bg-home.png", "温暖夜空背景，深蓝色渐变到紫色，散布着闪闪的小星星和弯弯月亮，柔和云朵，治愈系风格，适合小程序首页，不抢眼，低饱和度"),
        ("bg-chat.png", "聊天背景图，柔和的淡紫色和淡蓝色渐变，轻盈的云朵图案，温暖治愈，简洁不抢眼，适合对话界面，低饱和度"),
        ("bg-story.png", "睡前故事背景，温馨的暖橙色调，柔和的光晕，书本和星星元素，治愈系风格，温暖安心，低饱和度")
    ]
    
    for filename, prompt in bg_prompts:
        generate_image(prompt, "928*1664", f"{OUTPUT_DIR}/backgrounds/{filename}")
        time.sleep(2)
    
    # ========== 4. 晚安图模板 (5 个，750x1334) ==========
    print("\n📌 第四部分：晚安图模板")
    goodnight_prompts = [
        ("goodnight-sad.png", "晚安图模板，委屈情绪主题，温暖抱抱的治愈场景，柔和紫色调，预留文字位置，温馨安慰，治愈系风格，低饱和度"),
        ("goodnight-happy.png", "晚安图模板，开心情绪主题，欢快温暖的场景，明亮橙黄色调，星星和彩带，预留文字位置，治愈系风格，低饱和度"),
        ("goodnight-tired.png", "晚安图模板，疲惫情绪主题，宁静放松的场景，淡蓝色调，月亮和云朵，预留文字位置，温馨安慰，治愈系风格，低饱和度"),
        ("goodnight-anxious.png", "晚安图模板，焦虑情绪主题，平静安心的场景，柔和绿色和蓝色，治愈系风格，预留文字位置，温暖希望，低饱和度"),
        ("goodnight-peaceful.png", "晚安图模板，平静情绪主题，宁静夜空，深蓝色调，星星月亮，预留文字位置，晚安好梦，治愈系风格，低饱和度")
    ]
    
    for filename, prompt in goodnight_prompts:
        generate_image(prompt, "928*1664", f"{OUTPUT_DIR}/goodnight/{filename}")
        time.sleep(2)
    
    print("\n" + "=" * 60)
    print("✅ 所有 UI 素材生成完成！")
    print("=" * 60)
    print(f"\n📦 交付物位置：{OUTPUT_DIR}/")
    print("   - logo/     : Logo 设计")
    print("   - icons/    : 功能图标 (7 个)")
    print("   - backgrounds/ : 背景图 (3 个)")
    print("   - goodnight/ : 晚安图模板 (5 个)")
    print("\n🎨 配色方案：紫色/蓝色/橙色为主，温暖治愈系，低饱和度")
    print("📐 风格统一：圆润简洁，扁平化设计，透明背景")

if __name__ == "__main__":
    main()

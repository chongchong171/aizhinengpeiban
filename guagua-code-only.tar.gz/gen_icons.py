#!/usr/bin/env python3
# 快速生成剩余功能图标
import os
import dashscope
from dashscope import ImageSynthesis
import requests
import time

dashscope.api_key = "sk-d43b58a6d0dd486d89b69a38f305483a"

NEGATIVE = "低分辨率，模糊，水印，边框，文字扭曲，畸形"

def gen(prompt, path):
    print(f"🎨 {path}")
    try:
        resp = ImageSynthesis.call(
            model=ImageSynthesis.Models.wanx_v1,
            prompt=prompt,
            negative_prompt=NEGATIVE,
            size="1024*1024",
            n=1
        )
        if resp.status_code == 200:
            url = resp.output.results[0].url
            data = requests.get(url).content
            with open(path, 'wb') as f:
                f.write(data)
            print(f"   ✅ OK")
            return True
        else:
            print(f"   ❌ {resp.message}")
            return False
    except Exception as e:
        print(f"   ❌ {e}")
        return False

# 剩余图标
icons = [
    ("icon-alarm.png", "闹钟图标，睡前提醒功能，柔和橙色，圆润可爱，简洁扁平化，透明背景"),
    ("icon-user.png", "用户图标，个人中心，人形轮廓，温暖紫色，圆润友好，扁平化，透明背景")
]

for name, prompt in icons:
    gen(prompt, f"/root/.openclaw/workspace/guagua-miniprogram/images/icons/{name}")
    time.sleep(1)

print("✅ 图标完成")

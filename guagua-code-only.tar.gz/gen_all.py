#!/usr/bin/env python3
import dashscope
from dashscope import ImageSynthesis
import requests
import time

dashscope.api_key = "sk-d43b58a6d0dd486d89b69a38f305483a"

def gen_async(prompt, path, size="1024*1024"):
    print(f"🎨 {path}")
    try:
        # 异步调用
        resp = ImageSynthesis.async_call(
            model='wanx-v1',
            prompt=prompt,
            size=size,
            n=1
        )
        
        if resp.status_code == 200:
            task_id = resp.output.task_id
            print(f"   任务 ID: {task_id}")
            
            # 轮询任务状态
            while True:
                task_resp = ImageSynthesis.fetch(task_id)
                status = task_resp.output.task_status
                print(f"   状态：{status}")
                
                if status == 'SUCCEEDED':
                    url = task_resp.output.results[0].url
                    data = requests.get(url).content
                    with open(path, 'wb') as f:
                        f.write(data)
                    print(f"   ✅ 完成")
                    return True
                elif status == 'FAILED':
                    print(f"   ❌ 失败：{task_resp.output.message}")
                    return False
                time.sleep(3)
        else:
            print(f"   ❌ {resp.message}")
            return False
    except Exception as e:
        print(f"   ❌ {e}")
        return False

# 剩余图标
print("=== 生成剩余图标 ===")
gen_async("闹钟图标，睡前提醒，柔和橙色，圆润可爱，扁平化", 
          "/root/.openclaw/workspace/guagua-miniprogram/images/icons/icon-alarm.png")

gen_async("用户图标，个人中心，人形轮廓，温暖紫色，扁平化",
          "/root/.openclaw/workspace/guagua-miniprogram/images/icons/icon-user.png")

# 背景图
print("\n=== 生成背景图 ===")
gen_async("温暖夜空背景，深蓝色渐变紫色，星星月亮，柔和云朵，治愈系，低饱和度",
          "/root/.openclaw/workspace/guagua-miniprogram/images/backgrounds/bg-home.png",
          "928*1664")

gen_async("聊天背景，淡紫色淡蓝色渐变，轻盈云朵，温暖治愈，简洁",
          "/root/.openclaw/workspace/guagua-miniprogram/images/backgrounds/bg-chat.png",
          "928*1664")

gen_async("睡前故事背景，暖橙色调，柔和光晕，书本星星，治愈温馨",
          "/root/.openclaw/workspace/guagua-miniprogram/images/backgrounds/bg-story.png",
          "928*1664")

# 晚安图
print("\n=== 生成晚安图 ===")
gen_async("晚安图，委屈情绪，温暖抱抱，柔和紫色，预留文字位置，治愈",
          "/root/.openclaw/workspace/guagua-miniprogram/images/goodnight/goodnight-sad.png",
          "928*1664")

gen_async("晚安图，开心情绪，欢快温暖，明亮橙黄，星星彩带，预留文字",
          "/root/.openclaw/workspace/guagua-miniprogram/images/goodnight/goodnight-happy.png",
          "928*1664")

gen_async("晚安图，疲惫情绪，宁静放松，淡蓝色，月亮云朵，预留文字",
          "/root/.openclaw/workspace/guagua-miniprogram/images/goodnight/goodnight-tired.png",
          "928*1664")

gen_async("晚安图，焦虑情绪，平静安心，柔和绿蓝色，预留文字，温暖希望",
          "/root/.openclaw/workspace/guagua-miniprogram/images/goodnight/goodnight-anxious.png",
          "928*1664")

gen_async("晚安图，平静情绪，宁静夜空，深蓝色，星星月亮，晚安好梦",
          "/root/.openclaw/workspace/guagua-miniprogram/images/goodnight/goodnight-peaceful.png",
          "928*1664")

print("\n✅ 全部完成！")

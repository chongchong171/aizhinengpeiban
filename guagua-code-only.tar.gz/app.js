/**
 * 瓜瓜陪伴微信小程序 - 主入口文件
 * 
 * @author 玄枢
 * @date 2026-03-15
 * @description 小程序全局配置和生命周期管理
 */

App({
  /**
   * 全局数据
   */
  globalData: {
    userInfo: null,           // 用户信息
    themeColor: '#FF6B81',    // 主题色（温暖粉色）
    apiBase: '',              // API 基础地址（暂空，不使用付费 API）
    hasLogin: false           // 登录状态
  },

  /**
   * 小程序启动时执行
   */
  onLaunch() {
    console.log('瓜瓜陪伴小程序启动啦~ 🐾');
    
    // 检查登录状态
    this.checkLoginStatus();
    
    // 初始化本地存储数据
    this.initLocalStorage();
  },

  /**
   * 检查用户登录状态
   */
  checkLoginStatus() {
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.globalData.userInfo = userInfo;
      this.globalData.hasLogin = true;
    }
  },

  /**
   * 初始化本地存储数据
   * 用于存储聊天记录、心情日记等
   */
  initLocalStorage() {
    // 初始化聊天记录存储
    if (!wx.getStorageSync('chatHistory')) {
      wx.setStorageSync('chatHistory', []);
    }
    
    // 初始化心情记录存储
    if (!wx.getStorageSync('moodRecords')) {
      wx.setStorageSync('moodRecords', []);
    }
    
    // 初始化成就记录存储
    if (!wx.getStorageSync('achievements')) {
      wx.setStorageSync('achievements', []);
    }
  },

  /**
   * 全局工具方法：显示加载提示
   */
  showLoading(title = '加载中...') {
    wx.showLoading({
      title,
      mask: true
    });
  },

  /**
   * 全局工具方法：隐藏加载提示
   */
  hideLoading() {
    wx.hideLoading();
  },

  /**
   * 全局工具方法：显示成功提示
   */
  showSuccess(title) {
    wx.showToast({
      title,
      icon: 'success',
      duration: 2000
    });
  },

  /**
   * 全局工具方法：显示错误提示
   */
  showError(title) {
    wx.showToast({
      title,
      icon: 'none',
      duration: 2000
    });
  }
});
